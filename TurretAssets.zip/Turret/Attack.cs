using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour
{
    public GameObject player;
    public GameObject projectilePrefab;
    private float time = 0.0f;

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        if (time >= 3)
        {
            Instantiate(projectilePrefab, transform.position + 1 * transform.forward, transform.rotation);
            time = 0.0f;
        }
    }
}