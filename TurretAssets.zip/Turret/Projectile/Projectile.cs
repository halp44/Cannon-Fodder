using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public GameObject player;
    public Vector3 playerLocation;
    public float speed = 50.0f;

    void Start()
    {
        Vector3 playerLocation = new Vector3(player.transform.position.x + Random.Range(-3.0f, 3.0f), player.transform.position.y - 10, player.transform.position.z + Random.Range(-3.0f, 3.0f));
        transform.rotation = Quaternion.LookRotation(playerLocation);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += transform.forward * speed * Time.deltaTime;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "cannon")
        {
            Destroy(gameObject);
        }
    }
}