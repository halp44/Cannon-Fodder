using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonBall : MonoBehaviour
{

    public GameObject cannonBall;
    public float power;
    public Vector3 pos;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("space"))
        {
            Vector3 addpos = new Vector3(-9.4f, 4.83f, -1.47f);
            Instantiate(cannonBall, addpos, transform.rotation);
        }
    }
}
